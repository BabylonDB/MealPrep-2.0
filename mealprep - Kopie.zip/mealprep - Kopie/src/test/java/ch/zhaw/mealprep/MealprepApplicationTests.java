package ch.zhaw.mealprep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MealprepApplicationTests {

	@Test
	void contextLoads() {
	}

}
